﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace KeywordLearning
{
    public class datatypesdemo
    {
        int a = 10;
        float b = 12;
        double c = 17;
        string d = "ganesh";
        bool e=false;
        byte f = 12;
        uint g = 6;
        ulong h = 7;
        const int p= 3;
        decimal i = 2.23m;
        public void disp()
        {
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
            Console.WriteLine(e);
            Console.WriteLine(f);
            Console.WriteLine(g);
            Console.WriteLine(h);
            Console.WriteLine(p);
            Console.WriteLine(i);
            //Console.WriteLine(a);

        }


    }
}
