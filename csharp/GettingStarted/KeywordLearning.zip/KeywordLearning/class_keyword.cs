﻿namespace KeywordLearning
{
    public class class_keyword
    {
        public void display() {
            int[] arr = new int[] {1,2,3,4,5};
            foreach (int i in arr)
            {
                System.Console.WriteLine(i);
            }
             }
        public void calculate()
        {
            System.Console.WriteLine("2*2=4");
        }
    }
}
