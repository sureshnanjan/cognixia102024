﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeywordLearning
{
    public class sizedemo
    {
       public void display()
        {
            Console.WriteLine("size of int is "+sizeof(int));
            Console.WriteLine("size of float is"+sizeof(float));
            Console.WriteLine("size of double is"+sizeof(double));
            Console.WriteLine("short is"+sizeof(short));
            Console.WriteLine("decimal"+sizeof(decimal));
            Console.WriteLine("byte is"+sizeof(byte));
            Console.WriteLine("sbyte is"+sizeof(sbyte));
            Console.WriteLine("ushort is"+sizeof(ushort));
            Console.WriteLine("uint is"+sizeof(uint));
            Console.WriteLine("ulong is"+sizeof(ulong));
            Console.WriteLine("char is"+sizeof(char));
            Console.WriteLine("bool is"+sizeof(bool)); 
            //Console.WriteLine(sizeof(int));




        }


    }
}
