﻿namespace GettingStarted
{
    internal class Participant
    {
        string employee_code;
        string fname;
        string lname;
    }
}