﻿namespace PetstoreModel
{
    public class User
    {
        int id;
        string name;
        string fname;
        string lname;

    }
}
