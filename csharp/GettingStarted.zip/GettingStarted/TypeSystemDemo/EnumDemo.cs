﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeSystemDemo
{
    public enum EnumDemo
    {
    }
    public enum weeks
    {
        Sunday ,
        Monday ,
        Tuesday ,
        Wednesday ,
        Thursday ,
        Friday ,
        Saturday 
    }

    public enum DayofWeek {
        sunday,
        momday,
        tuesday,
        wednesday,
        thursday
    }
}
