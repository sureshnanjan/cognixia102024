﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeSystemDemo
{
    public class Bird : IMove
    {
        public void Move()
        {
            throw new NotImplementedException();
        }
    }
}
