﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeSystemDemo
{
    public class Bike: IMove
    {
        public Bike()
        {
            
        }

        public void Move()
        {
            Car car = new Car();
            
        }
    }
}
